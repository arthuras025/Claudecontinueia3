import Sidebar from '@/components/Sidebar'
import { supabaseServer } from '@/lib/supabase'

export default async function DashboardPage() {
  const supabase = supabaseServer()
  const { data: projects } = await supabase.from('projects').select('*').order('created_at', { ascending: false }).limit(5)
  const { data: agents } = await supabase.from('agents').select('*')

  const activeProjects = projects?.filter(p => p.status === 'active').length ?? 0
  const onlineAgents = agents?.filter(a => a.status === 'online').length ?? 0

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-8 bg-white">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">Dashboard</h1>
            <p className="text-sm text-gray-500 mt-0.5">Bem-vindo de volta</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 inline-block"></span>
            <span className="text-xs text-green-700">Produção ativa</span>
          </div>
        </div>

        {/* Métricas */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Projetos ativos', value: activeProjects },
            { label: 'Agentes online', value: onlineAgents },
            { label: 'Req. hoje', value: '4.8k' },
            { label: 'MRR', value: '$1.2k' },
          ].map((m) => (
            <div key={m.label} className="bg-gray-50 rounded-xl p-4">
              <div className="text-xs text-gray-500 mb-1">{m.label}</div>
              <div className="text-2xl font-semibold text-gray-900">{m.value}</div>
            </div>
          ))}
        </div>

        {/* Projetos */}
        <div className="border border-gray-100 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <span className="text-sm font-medium text-gray-900">Projetos recentes</span>
            <a href="/builder" className="text-xs text-purple-600 hover:text-purple-800">+ Novo projeto</a>
          </div>
          {projects && projects.length > 0 ? (
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left px-5 py-3 text-xs text-gray-500 font-medium">Nome</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-500 font-medium">Status</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-500 font-medium">Criado</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((p) => (
                  <tr key={p.id} className="border-t border-gray-50 hover:bg-gray-50">
                    <td className="px-5 py-3 text-gray-900 font-medium">{p.name}</td>
                    <td className="px-5 py-3">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                        p.status === 'active' ? 'bg-green-50 text-green-700' :
                        p.status === 'paused' ? 'bg-amber-50 text-amber-700' :
                        'bg-red-50 text-red-700'
                      }`}>{p.status}</span>
                    </td>
                    <td className="px-5 py-3 text-gray-400 text-xs">
                      {new Date(p.created_at).toLocaleDateString('pt-BR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="px-5 py-12 text-center text-gray-400 text-sm">
              Nenhum projeto ainda. <a href="/builder" className="text-purple-600">Crie o primeiro.</a>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
