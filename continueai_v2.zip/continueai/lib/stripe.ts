import Stripe from 'stripe'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
  typescript: true,
})

export const PLANS = {
  starter: {
    name: 'Starter',
    price: 0,
    priceId: null,
    limits: { projects: 3, agents: 1, requests: 1000 },
  },
  pro: {
    name: 'Pro',
    price: 1000, // centavos = $10
    priceId: process.env.STRIPE_PRO_PRICE_ID!,
    limits: { projects: -1, agents: 5, requests: 50000 },
  },
  enterprise: {
    name: 'Enterprise',
    price: null,
    priceId: null,
    limits: { projects: -1, agents: -1, requests: -1 },
  },
} as const

export type Plan = keyof typeof PLANS

export async function createCheckoutSession(userId: string, plan: 'pro') {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    mode: 'subscription',
    customer_email: undefined,
    metadata: { userId },
    line_items: [
      {
        price: PLANS[plan].priceId,
        quantity: 1,
      },
    ],
    success_url: `${process.env.NEXT_PUBLIC_APP_URL}/billing?success=true`,
    cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/billing?canceled=true`,
  })
  return session
}

export async function createPortalSession(customerId: string) {
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: `${process.env.NEXT_PUBLIC_APP_URL}/billing`,
  })
  return session
}
