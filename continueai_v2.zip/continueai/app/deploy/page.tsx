import Sidebar from '@/components/Sidebar'

const steps = [
  {
    num: 1,
    title: 'GitHub conectado',
    desc: 'Repositório: github.com/seu-usuario/continueai',
    status: 'done',
  },
  {
    num: 2,
    title: 'Vercel vinculado',
    desc: 'Deploy automático a cada push na branch main',
    status: 'done',
  },
  {
    num: 3,
    title: 'Variáveis de ambiente',
    desc: 'Configure na Vercel → Settings → Environment Variables',
    status: 'pending',
    env: [
      'NEXT_PUBLIC_SUPABASE_URL',
      'NEXT_PUBLIC_SUPABASE_ANON_KEY',
      'STRIPE_SECRET_KEY',
      'STRIPE_WEBHOOK_SECRET',
      'ANTHROPIC_API_KEY',
      'NEXT_PUBLIC_APP_URL',
    ],
  },
  {
    num: 4,
    title: 'Domínio customizado',
    desc: 'Compre em Registro.br → conecte na Vercel via CNAME',
    status: 'pending',
  },
  {
    num: 5,
    title: 'Go live',
    desc: 'Teste auth, billing e agentes em produção',
    status: 'upcoming',
  },
]

export default function DeployPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-8 bg-white">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">Deploy</h1>
            <p className="text-sm text-gray-500 mt-0.5">Pipeline completo GitHub → Vercel → Produção</p>
          </div>
          <span className="text-xs bg-green-50 text-green-700 px-3 py-1 rounded-full">Vercel conectado</span>
        </div>

        <div className="space-y-4">
          {steps.map((step) => (
            <div key={step.num} className="border border-gray-100 rounded-xl p-5">
              <div className="flex items-start gap-4">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5 ${
                  step.status === 'done' ? 'bg-green-50 text-green-700' :
                  step.status === 'pending' ? 'bg-amber-50 text-amber-700' :
                  'bg-gray-100 text-gray-400'
                }`}>
                  {step.status === 'done' ? '✓' : step.num}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium text-gray-900">{step.title}</div>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      step.status === 'done' ? 'bg-green-50 text-green-700' :
                      step.status === 'pending' ? 'bg-amber-50 text-amber-700' :
                      'bg-gray-100 text-gray-400'
                    }`}>
                      {step.status === 'done' ? 'Feito' : step.status === 'pending' ? 'Pendente' : 'Em breve'}
                    </span>
                  </div>
                  <div className="text-xs text-gray-400 mt-1">{step.desc}</div>

                  {step.env && (
                    <div className="mt-3 bg-gray-50 rounded-lg p-3 font-mono text-xs text-gray-600 space-y-1">
                      {step.env.map((key) => (
                        <div key={key}><span className="text-gray-900">{key}</span>=<span className="text-gray-400">sua_chave_aqui</span></div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 grid grid-cols-2 gap-4">
          <a
            href="https://vercel.com/new"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 py-3 bg-gray-900 text-white text-sm rounded-xl hover:bg-gray-700"
          >
            Abrir Vercel Dashboard →
          </a>
          <a
            href="https://supabase.com/dashboard"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 py-3 border border-gray-200 text-gray-700 text-sm rounded-xl hover:bg-gray-50"
          >
            Abrir Supabase Dashboard →
          </a>
        </div>
      </main>
    </div>
  )
}
