'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LayoutDashboard, Zap, Bot, CreditCard, Rocket, Settings, LogOut } from 'lucide-react'

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, section: 'principal' },
  { href: '/builder', label: 'App Builder', icon: Zap, section: 'principal' },
  { href: '/agents', label: 'Agentes', icon: Bot, section: 'plataforma' },
  { href: '/billing', label: 'Billing', icon: CreditCard, section: 'plataforma' },
  { href: '/deploy', label: 'Deploy', icon: Rocket, section: 'plataforma' },
]

export default function Sidebar() {
  const path = usePathname()

  return (
    <aside className="w-52 flex-shrink-0 border-r border-gray-100 bg-gray-50 flex flex-col min-h-screen">
      <div className="px-4 py-5 border-b border-gray-100">
        <div className="font-semibold text-gray-900 text-sm">ContinueAI</div>
        <div className="text-xs text-gray-400 mt-0.5">SaaS · Agents · Builder</div>
      </div>

      <nav className="flex-1 py-3">
        {['principal', 'plataforma'].map((section) => (
          <div key={section} className="mb-2">
            <div className="px-4 py-2 text-[10px] font-medium text-gray-400 uppercase tracking-widest">
              {section}
            </div>
            {navItems.filter(i => i.section === section).map((item) => {
              const Icon = item.icon
              const active = path === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-2.5 px-4 py-2 text-sm transition-colors ${
                    active
                      ? 'bg-white text-gray-900 font-medium border-r-2 border-gray-900'
                      : 'text-gray-500 hover:text-gray-900 hover:bg-white'
                  }`}
                >
                  <Icon size={15} className={active ? 'text-gray-900' : 'text-gray-400'} />
                  {item.label}
                </Link>
              )
            })}
          </div>
        ))}
      </nav>

      <div className="px-4 py-4 border-t border-gray-100 space-y-1">
        <Link href="/settings" className="flex items-center gap-2.5 px-0 py-2 text-sm text-gray-500 hover:text-gray-900">
          <Settings size={15} /> Configurações
        </Link>
        <Link href="/logout" className="flex items-center gap-2.5 px-0 py-2 text-sm text-gray-500 hover:text-red-600">
          <LogOut size={15} /> Sair
        </Link>
      </div>
    </aside>
  )
}
