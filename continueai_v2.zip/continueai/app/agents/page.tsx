import Sidebar from '@/components/Sidebar'
import { supabaseServer } from '@/lib/supabase'

export default async function AgentsPage() {
  const supabase = supabaseServer()
  const { data: agents } = await supabase.from('agents').select('*').order('created_at', { ascending: false })

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-8 bg-white">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">Agentes</h1>
            <p className="text-sm text-gray-500 mt-0.5">Gerencie seus AI Agents</p>
          </div>
          <a href="/agents/new" className="px-4 py-2 bg-gray-900 text-white text-sm rounded-lg hover:bg-gray-700">
            + Novo agente
          </a>
        </div>

        <div className="space-y-3">
          {agents && agents.length > 0 ? agents.map((agent) => (
            <div key={agent.id} className="border border-gray-100 rounded-xl p-5 flex items-center gap-4 hover:bg-gray-50">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg ${
                agent.status === 'online' ? 'bg-green-50' :
                agent.status === 'error' ? 'bg-red-50' : 'bg-gray-100'
              }`}>
                🤖
              </div>
              <div className="flex-1">
                <div className="font-medium text-gray-900 text-sm">{agent.name}</div>
                <div className="text-xs text-gray-400 mt-0.5">{agent.model} · {agent.calls_today} chamadas hoje</div>
              </div>
              <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                agent.status === 'online' ? 'bg-green-50 text-green-700' :
                agent.status === 'error' ? 'bg-red-50 text-red-700' :
                'bg-amber-50 text-amber-700'
              }`}>
                {agent.status}
              </span>
              <a href={`/agents/${agent.id}`} className="text-xs text-purple-600 hover:text-purple-800 ml-2">
                Configurar →
              </a>
            </div>
          )) : (
            <div className="border border-dashed border-gray-200 rounded-xl py-16 text-center">
              <div className="text-3xl mb-3">🤖</div>
              <div className="text-sm text-gray-500 mb-4">Nenhum agente configurado ainda</div>
              <a href="/agents/new" className="text-sm text-purple-600 hover:text-purple-800">
                Criar primeiro agente →
              </a>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
