# ContinueAI

> AI App Builder · Agent Platform · SaaS Engine

Stack completa para lançar um SaaS com IA em produção.

---

## Stack

| Camada | Tecnologia |
|---|---|
| Frontend | Next.js 14 (App Router) + Tailwind CSS |
| Auth + DB | Supabase |
| Payments | Stripe (checkout + webhooks) |
| AI | Claude (Anthropic API) — streaming |
| Deploy | Vercel |

---

## Instalação rápida

```bash
# 1. Clonar
git clone https://github.com/seu-usuario/continueai
cd continueai

# 2. Instalar dependências
npm install

# 3. Configurar variáveis de ambiente
cp .env.local.example .env.local
# Edite o .env.local com suas chaves

# 4. Rodar localmente
npm run dev
```

Acesse: http://localhost:3000

---

## Variáveis de ambiente

```env
# Supabase (https://supabase.com/dashboard)
NEXT_PUBLIC_SUPABASE_URL=https://SEU_PROJETO.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua_anon_key
SUPABASE_SERVICE_ROLE_KEY=sua_service_role_key

# Stripe (https://dashboard.stripe.com)
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_PRO_PRICE_ID=price_...

# Anthropic (https://console.anthropic.com)
ANTHROPIC_API_KEY=sk-ant-...

# App
NEXT_PUBLIC_APP_URL=https://seuapp.vercel.app
```

---

## Banco de dados (Supabase)

Execute este SQL no Supabase SQL Editor:

```sql
-- Projetos
create table projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  name text not null,
  description text,
  status text default 'active' check (status in ('active','paused','error')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Agentes
create table agents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  project_id uuid references projects(id) on delete cascade,
  name text not null,
  model text default 'claude-sonnet-4-6',
  system_prompt text,
  status text default 'online' check (status in ('online','paused','error')),
  calls_today integer default 0,
  created_at timestamptz default now()
);

-- Assinaturas
create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade unique,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan text default 'starter' check (plan in ('starter','pro','enterprise')),
  status text default 'active',
  current_period_end timestamptz
);

-- RLS
alter table projects enable row level security;
alter table agents enable row level security;
alter table subscriptions enable row level security;

create policy "users own projects" on projects for all using (auth.uid() = user_id);
create policy "users own agents" on agents for all using (auth.uid() = user_id);
create policy "users own subscriptions" on subscriptions for all using (auth.uid() = user_id);
```

---

## Deploy na Vercel

1. Push no GitHub
2. Importe o repositório na [Vercel](https://vercel.com/new)
3. Adicione todas as variáveis de ambiente
4. Clique em **Deploy**

### Webhook Stripe

Configure o webhook no Stripe Dashboard apontando para:
```
https://seuapp.vercel.app/api/webhook
```
Eventos necessários: `checkout.session.completed`, `customer.subscription.deleted`, `invoice.payment_failed`

---

## Estrutura do projeto

```
continueai/
├── app/
│   ├── page.tsx              # Landing page
│   ├── layout.tsx
│   ├── globals.css
│   ├── login/page.tsx        # Auth
│   ├── register/page.tsx
│   ├── dashboard/page.tsx    # Dashboard principal
│   ├── builder/page.tsx      # AI App Builder (streaming)
│   ├── agents/page.tsx       # Gerenciador de agentes
│   ├── billing/page.tsx      # Planos + Stripe
│   ├── deploy/page.tsx       # Pipeline de deploy
│   └── api/
│       ├── builder/route.ts  # Streaming Claude
│       ├── checkout/route.ts # Stripe checkout
│       └── webhook/route.ts  # Stripe webhooks
├── components/
│   └── Sidebar.tsx
├── lib/
│   ├── supabase.ts
│   ├── stripe.ts
│   └── anthropic.ts
├── .env.local.example
├── next.config.js
├── tailwind.config.ts
└── package.json
```

---

## Licença

MIT
