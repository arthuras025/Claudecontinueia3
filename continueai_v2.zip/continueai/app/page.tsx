import Link from 'next/link'

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="flex items-center justify-between px-8 py-4 border-b border-gray-100">
        <div>
          <span className="text-lg font-semibold text-gray-900">ContinueAI</span>
          <span className="ml-2 text-xs text-gray-400">AI App Builder · Agent Platform · SaaS Engine</span>
        </div>
        <div className="flex gap-3">
          <Link href="/login" className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900">Entrar</Link>
          <Link href="/register" className="px-4 py-2 text-sm bg-gray-900 text-white rounded-lg hover:bg-gray-700">
            Começar grátis
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-4xl mx-auto text-center pt-24 pb-16 px-4">
        <div className="inline-block px-3 py-1 bg-purple-50 text-purple-700 text-xs rounded-full mb-6">
          AI App Builder + Agent Platform + SaaS Engine
        </div>
        <h1 className="text-5xl font-semibold text-gray-900 mb-6 leading-tight">
          Construa apps com IA.<br />Lance seu SaaS hoje.
        </h1>
        <p className="text-xl text-gray-500 mb-10 max-w-2xl mx-auto">
          Crie projetos, gerencie agentes de IA, processe pagamentos e faça deploy — tudo em um painel.
        </p>
        <div className="flex gap-4 justify-center">
          <Link href="/register" className="px-6 py-3 bg-gray-900 text-white rounded-lg text-sm hover:bg-gray-700 font-medium">
            Começar grátis
          </Link>
          <Link href="/dashboard" className="px-6 py-3 border border-gray-200 text-gray-700 rounded-lg text-sm hover:bg-gray-50">
            Ver demo
          </Link>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-5xl mx-auto px-4 pb-24">
        <div className="grid grid-cols-3 gap-6">
          {[
            { icon: '⚡', title: 'AI App Builder', desc: 'Descreva o app e receba código completo com UI, backend e API gerados por IA.' },
            { icon: '🤖', title: 'Agent Platform', desc: 'Configure agentes de IA com modelos Claude, ferramentas e memória persistente.' },
            { icon: '💰', title: 'SaaS Engine', desc: 'Billing com Stripe, auth com Supabase, deploy com Vercel. Tudo integrado.' },
          ].map((f) => (
            <div key={f.title} className="p-6 border border-gray-100 rounded-xl">
              <div className="text-2xl mb-3">{f.icon}</div>
              <h3 className="font-medium text-gray-900 mb-2">{f.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  )
}
