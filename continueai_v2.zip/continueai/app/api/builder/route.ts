import { NextRequest } from 'next/server'

export const runtime = 'edge'

const SYSTEM_PROMPT = `Você é o ContinueAI Builder — especialista em criar apps com Next.js 14, Supabase, Stripe e Tailwind CSS.

Quando o usuário descrever um app ou feature:
1. Gere o código completo e funcional em TypeScript
2. Use blocos de código com a linguagem correta
3. Explique brevemente cada arquivo
4. Indique os próximos passos

Sempre use App Router do Next.js 14. Responda em português.`

export async function POST(req: NextRequest) {
  const { messages } = await req.json()

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY!,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 4096,
      stream: true,
      system: SYSTEM_PROMPT,
      messages,
    }),
  })

  if (!res.ok) {
    return new Response(JSON.stringify({ error: 'Anthropic API error' }), { status: 500 })
  }

  return new Response(res.body, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  })
}
