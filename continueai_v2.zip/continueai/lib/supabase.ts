import { createClient } from '@supabase/supabase-js'
import { createClientComponentClient, createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

export type Database = {
  public: {
    Tables: {
      projects: {
        Row: {
          id: string
          user_id: string
          name: string
          description: string | null
          status: 'active' | 'paused' | 'error'
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['projects']['Row'], 'id' | 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['projects']['Insert']>
      }
      agents: {
        Row: {
          id: string
          user_id: string
          project_id: string
          name: string
          model: string
          system_prompt: string
          status: 'online' | 'paused' | 'error'
          calls_today: number
          created_at: string
        }
        Insert: Omit<Database['public']['Tables']['agents']['Row'], 'id' | 'created_at' | 'calls_today'>
        Update: Partial<Database['public']['Tables']['agents']['Insert']>
      }
      subscriptions: {
        Row: {
          id: string
          user_id: string
          stripe_customer_id: string
          stripe_subscription_id: string
          plan: 'starter' | 'pro' | 'enterprise'
          status: 'active' | 'canceled' | 'past_due'
          current_period_end: string
        }
      }
    }
  }
}

// Client-side
export const supabaseClient = () => createClientComponentClient<Database>()

// Server-side
export const supabaseServer = () =>
  createServerComponentClient<Database>({ cookies })

// Admin (service role — usar só em API routes)
export const supabaseAdmin = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)
