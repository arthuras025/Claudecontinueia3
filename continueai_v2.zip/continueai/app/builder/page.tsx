'use client'
import { useState, useRef, useEffect } from 'react'
import Sidebar from '@/components/Sidebar'
import { Send, Bot, User } from 'lucide-react'

type Message = { role: 'user' | 'assistant'; content: string }

const SYSTEM_PROMPT = `Você é o ContinueAI Builder — um assistente especialista em criar apps com Next.js, Supabase, Stripe e Tailwind CSS.

Quando o usuário descrever um app ou feature, você:
1. Gera o código completo e funcional
2. Explica cada parte brevemente
3. Indica os próximos passos de integração

Sempre use TypeScript. Siga as melhores práticas do Next.js 14 com App Router.
Responda em português.`

export default function BuilderPage() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Olá! Descreva o app ou feature que você quer criar e eu gero o código completo para você.' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  async function send() {
    if (!input.trim() || loading) return
    const userMsg: Message = { role: 'user', content: input }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setLoading(true)

    try {
      const res = await fetch('/api/builder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...messages, userMsg] }),
      })

      if (!res.body) throw new Error('No stream')
      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let aiText = ''
      setMessages(prev => [...prev, { role: 'assistant', content: '' }])

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        const chunk = decoder.decode(value)
        const lines = chunk.split('\n').filter(l => l.startsWith('data: '))
        for (const line of lines) {
          const data = line.replace('data: ', '')
          if (data === '[DONE]') break
          try {
            const parsed = JSON.parse(data)
            const text = parsed.delta?.text || ''
            aiText += text
            setMessages(prev => {
              const updated = [...prev]
              updated[updated.length - 1] = { role: 'assistant', content: aiText }
              return updated
            })
          } catch {}
        }
      }
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Erro ao conectar com a IA. Verifique sua ANTHROPIC_API_KEY.' }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 flex flex-col bg-white">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h1 className="text-sm font-semibold text-gray-900">AI App Builder</h1>
            <p className="text-xs text-gray-400">Claude Sonnet 4.6 · código gerado em tempo real</p>
          </div>
          <span className="text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded-full">streaming ativo</span>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-4 scrollbar-thin">
          {messages.map((m, i) => (
            <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${
                m.role === 'assistant' ? 'bg-purple-100' : 'bg-gray-100'
              }`}>
                {m.role === 'assistant' ? <Bot size={14} className="text-purple-600" /> : <User size={14} className="text-gray-500" />}
              </div>
              <div className={`max-w-[75%] text-sm rounded-2xl px-4 py-3 leading-relaxed whitespace-pre-wrap ${
                m.role === 'assistant'
                  ? 'bg-gray-50 text-gray-800'
                  : 'bg-gray-900 text-white'
              }`}>
                {m.content || (loading && i === messages.length - 1 ? (
                  <span className="flex gap-1 items-center">
                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{animationDelay:'0ms'}}/>
                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{animationDelay:'150ms'}}/>
                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{animationDelay:'300ms'}}/>
                  </span>
                ) : '')}
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        <div className="px-6 py-4 border-t border-gray-100">
          <div className="flex gap-3 items-end">
            <textarea
              className="flex-1 resize-none border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-purple-200 min-h-[52px] max-h-32"
              placeholder="Ex: crie um componente de onboarding com 3 steps e validação..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
              rows={1}
            />
            <button
              onClick={send}
              disabled={loading || !input.trim()}
              className="w-10 h-10 bg-gray-900 text-white rounded-xl flex items-center justify-center hover:bg-gray-700 disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
            >
              <Send size={16} />
            </button>
          </div>
          <p className="text-xs text-gray-400 mt-2">Enter para enviar · Shift+Enter para nova linha</p>
        </div>
      </main>
    </div>
  )
}
