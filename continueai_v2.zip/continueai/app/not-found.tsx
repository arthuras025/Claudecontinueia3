import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="text-center">
        <div className="text-6xl font-bold text-gray-200 mb-4">404</div>
        <div className="text-xl font-semibold text-gray-900 mb-2">Página não encontrada</div>
        <div className="text-sm text-gray-500 mb-8">Esta rota não existe no projeto.</div>
        <Link href="/" className="px-5 py-2.5 bg-gray-900 text-white text-sm rounded-lg hover:bg-gray-700">
          Voltar para o início
        </Link>
      </div>
    </div>
  )
}
