'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function RegisterPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  async function register(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const { createClientComponentClient } = await import('@supabase/auth-helpers-nextjs')
      const supabase = createClientComponentClient()
      const { error } = await supabase.auth.signUp({ email, password })
      if (error) setError(error.message)
      else router.push('/dashboard')
    } catch {
      setError('Erro de conexão. Verifique as variáveis no Vercel.')
    }
    setLoading(false)
  }

  return (
    <div style={{minHeight:'100vh',background:'#f9fafb',display:'flex',alignItems:'center',justifyContent:'center',padding:'0 16px',fontFamily:'system-ui,sans-serif'}}>
      <div style={{width:'100%',maxWidth:'360px'}}>
        <div style={{textAlign:'center',marginBottom:'32px'}}>
          <div style={{fontSize:'22px',fontWeight:600,color:'#111'}}>ContinueAI</div>
          <div style={{fontSize:'14px',color:'#6b7280',marginTop:'4px'}}>Crie sua conta grátis</div>
        </div>
        <form onSubmit={register} style={{background:'#fff',border:'1px solid #ebebeb',borderRadius:'16px',padding:'32px',display:'flex',flexDirection:'column',gap:'16px'}}>
          {error && <div style={{fontSize:'13px',color:'#dc2626',background:'#fef2f2',padding:'10px 12px',borderRadius:'8px'}}>{error}</div>}
          <div>
            <label style={{display:'block',fontSize:'12px',fontWeight:500,color:'#374151',marginBottom:'6px'}}>Email</label>
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} required
              style={{width:'100%',border:'1px solid #e5e7eb',borderRadius:'8px',padding:'10px 12px',fontSize:'14px',outline:'none',boxSizing:'border-box'}}
              placeholder="voce@email.com"/>
          </div>
          <div>
            <label style={{display:'block',fontSize:'12px',fontWeight:500,color:'#374151',marginBottom:'6px'}}>Senha</label>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={6}
              style={{width:'100%',border:'1px solid #e5e7eb',borderRadius:'8px',padding:'10px 12px',fontSize:'14px',outline:'none',boxSizing:'border-box'}}
              placeholder="mínimo 6 caracteres"/>
          </div>
          <button type="submit" disabled={loading}
            style={{width:'100%',background:'#111',color:'#fff',border:'none',borderRadius:'8px',padding:'11px',fontSize:'14px',fontWeight:500,cursor:loading?'not-allowed':'pointer',opacity:loading?0.6:1}}>
            {loading ? 'Criando conta...' : 'Criar conta grátis'}
          </button>
          <p style={{textAlign:'center',fontSize:'13px',color:'#9ca3af',margin:0}}>
            Já tem conta? <a href="/login" style={{color:'#7c3aed'}}>Entrar</a>
          </p>
        </form>
      </div>
    </div>
  )
}
