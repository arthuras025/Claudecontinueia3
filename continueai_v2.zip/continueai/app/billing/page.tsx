'use client'
import { useState } from 'react'
import Sidebar from '@/components/Sidebar'

const PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    price: '$0',
    period: '/mês',
    desc: 'Para começar',
    features: ['3 projetos', '1 agente', '1k req/mês', 'Deploy Vercel'],
    current: true,
    cta: 'Plano atual',
  },
  {
    id: 'pro',
    name: 'Pro',
    price: '$10',
    period: '/mês',
    desc: 'Para times e produtos',
    features: ['Projetos ilimitados', '5 agentes', '50k req/mês', 'Deploy + domínio', 'Suporte prioritário'],
    current: false,
    cta: 'Fazer upgrade',
    featured: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 'Custom',
    period: '',
    desc: 'White-label + SLA',
    features: ['Tudo do Pro', 'Agentes ilimitados', 'Req. ilimitadas', 'White-label', 'SLA dedicado'],
    current: false,
    cta: 'Falar com time',
  },
]

export default function BillingPage() {
  const [loading, setLoading] = useState(false)

  async function upgrade(plan: string) {
    if (plan !== 'pro') { window.open('mailto:hello@continueai.com'); return }
    setLoading(true)
    try {
      const res = await fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ plan }) })
      const data = await res.json()
      if (data.url) window.location.href = data.url
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-8 bg-white">
        <div className="mb-8">
          <h1 className="text-xl font-semibold text-gray-900">Billing</h1>
          <p className="text-sm text-gray-500 mt-0.5">Gerencie seu plano e pagamentos</p>
        </div>

        {/* Uso atual */}
        <div className="border border-gray-100 rounded-xl p-6 mb-8">
          <div className="text-sm font-medium text-gray-900 mb-4">Uso do plano Starter</div>
          <div className="space-y-4">
            {[
              { label: 'Projetos', used: 3, total: 3 },
              { label: 'Requisições', used: 820, total: 1000 },
              { label: 'Agentes', used: 1, total: 1 },
            ].map((u) => {
              const pct = Math.round((u.used / u.total) * 100)
              return (
                <div key={u.label}>
                  <div className="flex justify-between text-xs text-gray-500 mb-1.5">
                    <span>{u.label}</span>
                    <span>{u.used} / {u.total}</span>
                  </div>
                  <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${pct >= 100 ? 'bg-red-400' : pct >= 80 ? 'bg-amber-400' : 'bg-green-400'}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              )
            })}
          </div>
          <p className="text-xs text-red-500 mt-4">Limite atingido — faça upgrade para continuar crescendo.</p>
        </div>

        {/* Planos */}
        <div className="grid grid-cols-3 gap-5">
          {PLANS.map((plan) => (
            <div key={plan.id} className={`border rounded-xl p-6 flex flex-col ${plan.featured ? 'border-2 border-purple-300' : 'border-gray-100'}`}>
              {plan.featured && (
                <span className="inline-block text-xs bg-purple-50 text-purple-700 px-2.5 py-1 rounded-full mb-3 self-start">Mais popular</span>
              )}
              <div className="text-xs text-gray-400 mb-1">{plan.name}</div>
              <div className="text-3xl font-semibold text-gray-900">{plan.price}<span className="text-sm font-normal text-gray-400">{plan.period}</span></div>
              <div className="text-xs text-gray-400 mt-1 mb-5">{plan.desc}</div>
              <ul className="space-y-2 flex-1 mb-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-xs text-gray-600">
                    <span className="w-3.5 h-3.5 rounded-full bg-green-50 flex items-center justify-center flex-shrink-0">
                      <svg width="8" height="8" viewBox="0 0 8 8"><path d="M1.5 4l2 2 3-3" stroke="#16a34a" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/></svg>
                    </span>
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => !plan.current && upgrade(plan.id)}
                disabled={plan.current || loading}
                className={`w-full py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  plan.current ? 'bg-gray-100 text-gray-400 cursor-default' :
                  plan.featured ? 'bg-gray-900 text-white hover:bg-gray-700' :
                  'border border-gray-200 text-gray-700 hover:bg-gray-50'
                }`}
              >
                {loading && plan.id === 'pro' ? 'Redirecionando...' : plan.cta}
              </button>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
